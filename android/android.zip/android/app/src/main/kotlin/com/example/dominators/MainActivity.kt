package com.example.dominators

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
